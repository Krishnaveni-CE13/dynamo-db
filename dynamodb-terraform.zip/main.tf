# ---------------------------------------------------------------------------
# DynamoDB table for today's activity.
#   - PAY_PER_REQUEST (on-demand): no capacity planning, no cost while idle.
#   - Only key attributes are declared; DynamoDB is schemaless for the rest.
# NOTE: we do NOT manage table items here (per the assignment).
# ---------------------------------------------------------------------------
resource "aws_dynamodb_table" "this" {
  name         = var.table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = var.hash_key

  attribute {
    name = var.hash_key
    type = "S" # S = string, N = number, B = binary
  }

  # --- Optional: add a sort key by uncommenting below and setting range_key ---
  # range_key = "sk"
  # attribute {
  #   name = "sk"
  #   type = "S"
  # }

  # --- Optional: a Global Secondary Index ------------------------------------
  # global_secondary_index {
  #   name            = "gsi1"
  #   hash_key        = "gsi1pk"
  #   projection_type = "ALL"
  # }
  # attribute {
  #   name = "gsi1pk"
  #   type = "S"
  # }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled = true # AWS-owned key by default; swap in a KMS CMK later if needed
  }

  tags = {
    Name = var.table_name
  }
}
