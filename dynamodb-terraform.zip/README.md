# DynamoDB with Terraform

Terraform code to create a DynamoDB table, with an **S3 remote backend** (and
DynamoDB state locking) to store `terraform.tfstate`.

> Table **items** are not managed by Terraform (per the assignment).

## Files
| File | Purpose |
|------|---------|
| `versions.tf` | Terraform + AWS provider versions and the **S3 backend block** |
| `providers.tf` | AWS provider + default tags |
| `variables.tf` | Input variables (region, table name, hash key, environment) |
| `main.tf` | The **DynamoDB table** resource |
| `outputs.tf` | Table name and ARN |
| `terraform.tfvars.example` | Sample values — copy to `terraform.tfvars` |
| `.gitignore` | Standard Terraform ignore list |

## Prerequisites
- Terraform >= 1.5, AWS CLI configured (`aws configure`) with credentials.

## One-time bootstrap (before `terraform init`)
The backend needs the S3 bucket and lock table to exist first. Pick a globally
unique bucket name and use it in both the command below and in `versions.tf`.

```bash
REGION=ap-southeast-1
BUCKET=REPLACE-ME-tfstate-your-unique-suffix

# S3 bucket for state (+ versioning)
aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
  --create-bucket-configuration LocationConstraint="$REGION"
aws s3api put-bucket-versioning --bucket "$BUCKET" \
  --versioning-configuration Status=Enabled

# DynamoDB lock table (name must match dynamodb_table in versions.tf)
aws dynamodb create-table \
  --table-name terraform-locks \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region "$REGION"
```

> On Terraform >= 1.10 you can set `use_lockfile = true` in the backend and skip
> the lock table entirely.

## Deploy
```bash
cp terraform.tfvars.example terraform.tfvars   # then edit values
terraform init      # configures the S3 backend
terraform fmt
terraform validate
terraform plan
terraform apply
```

Clean up when done: `terraform destroy`.

## Submit
Push to a **public** GitHub repo and submit its URL:
```bash
git init
git branch -M main
git add .
git commit -m "DynamoDB table with Terraform + S3 remote state backend"
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```
