provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "dynamodb-with-terraform"
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  }
}
