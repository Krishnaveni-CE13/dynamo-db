variable "aws_region" {
  description = "AWS region to deploy into."
  type        = string
  default     = "ap-southeast-1"
}

variable "environment" {
  description = "Environment name, used for tagging."
  type        = string
  default     = "dev"
}

variable "table_name" {
  description = "Name of the DynamoDB table."
  type        = string
  default     = "app-table"
}

variable "hash_key" {
  description = "Partition (hash) key attribute name."
  type        = string
  default     = "id"
}
