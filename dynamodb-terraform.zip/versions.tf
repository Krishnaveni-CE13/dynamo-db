terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # ---------------------------------------------------------------------------
  # Remote state backend: stores terraform.tfstate in S3, with a DynamoDB table
  # for state locking so two people can't apply at the same time.
  #
  # IMPORTANT: backend config cannot use variables, and the S3 bucket + lock
  # table must ALREADY EXIST before `terraform init`. Run the one-time bootstrap
  # commands in the README first, then replace the bucket name below with yours
  # (S3 bucket names are globally unique).
  # ---------------------------------------------------------------------------
  backend "s3" {
    bucket         = "REPLACE-ME-tfstate-your-unique-suffix"
    key            = "dynamodb-terraform/terraform.tfstate"
    region         = "ap-southeast-1"
    dynamodb_table = "terraform-locks"
    encrypt        = true

    # Terraform >= 1.10 can lock state natively in S3 instead of DynamoDB.
    # If you use this, you can skip creating the lock table above:
    # use_lockfile = true
  }
}
